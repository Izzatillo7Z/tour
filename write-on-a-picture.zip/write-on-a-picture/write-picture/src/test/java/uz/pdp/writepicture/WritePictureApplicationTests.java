package uz.pdp.writepicture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WritePictureApplicationTests {

    @Test
    void contextLoads() {
    }

}
