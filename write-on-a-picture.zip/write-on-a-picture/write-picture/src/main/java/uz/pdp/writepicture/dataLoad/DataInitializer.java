package uz.pdp.writepicture.dataLoad;


import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import uz.pdp.writepicture.entity.User;
import uz.pdp.writepicture.respository.UserRepository;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;

    @Override
    public void run(String... args) throws Exception {

        User user = User.builder()
                .chatId(963016524L)
                .isSuperAdmin(false)
                .isAdmin(true)
                .build();

        User user1 = User.builder()
                .chatId(526492949L)
                .isSuperAdmin(false)
                .isAdmin(true)
                .build();
        User user2 = User.builder()
                .chatId(400923742L)
                .isSuperAdmin(false)
                .isAdmin(true)
                .build();

        userRepository.save(user);
        userRepository.save(user1);
        userRepository.save(user2);

        System.out.println("User saqlandi");

    }
}
