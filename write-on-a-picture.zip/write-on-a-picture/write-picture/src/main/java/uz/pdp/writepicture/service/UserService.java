package uz.pdp.writepicture.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.pdp.writepicture.entity.User;
import uz.pdp.writepicture.respository.UserRepository;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;


    public void deleteUser(Long chatId){

        Optional<User> optionalUser = userRepository.findByChatId(chatId);
        if(optionalUser.isPresent()){
            User user = optionalUser.get();
            userRepository.deleteById(user.getId());
        }

    }

}
