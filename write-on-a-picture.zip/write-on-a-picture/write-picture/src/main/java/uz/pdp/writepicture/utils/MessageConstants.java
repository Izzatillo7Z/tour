package uz.pdp.writepicture.utils;

public interface MessageConstants {

    String ADD_ADMIN="➕ Admin qo'shish";

    String DELETE_ADMIN="➖ Adminni o'chirish";

    String DATE_REGEX = "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\\d{4}$";

    String JONASH_SANASI_MESSAGE="JO'NAB KETISH SANASI:";

    String QAYTISH_SANASI_MESSAGE="QAYTISH SANASI:";

    String SAYOHAT_DAVRI_MESSAGE="SAYOHAT DAVRI:";

    String KECHA_MESSAGE=" KECHA - ";

    String KUNDUZ_MESSAGE=" KUNDUZ";

}
