package uz.pdp.writepicture.enums;


public enum UserState {

    ASK_FROM,
    ASK_TO,
    ASK_DATE_FROM,
    ASK_DATE_TO,
    ASK_DURATION_DAY,
    ASK_DURATION_NIGHT,
    ASK_PRICE,
    COMPLETED

}
