package uz.pdp.writepicture.service;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import uz.pdp.writepicture.entity.User;
import uz.pdp.writepicture.respository.UserRepository;
import uz.pdp.writepicture.utils.MessageConstants;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ButtonService {


   private final UserRepository userRepository;


   public ReplyKeyboardMarkup getSuperAdminButton() {

      KeyboardButton addAdminButton = new KeyboardButton(MessageConstants.ADD_ADMIN);

      KeyboardButton deleteAdminButton = new KeyboardButton(MessageConstants.DELETE_ADMIN);

      KeyboardRow buttons = new KeyboardRow();
      buttons.add(addAdminButton);
      buttons.add(deleteAdminButton);

      ReplyKeyboardMarkup keyboard = new ReplyKeyboardMarkup();
      keyboard.setOneTimeKeyboard(true);
      keyboard.setResizeKeyboard(true);
      keyboard.setKeyboard(List.of(buttons));

      return keyboard;
   }

   public InlineKeyboardMarkup getAdminDeleteButton() {

      List<User> allByIsAdmin = userRepository.findAllAdmins();

      InlineKeyboardMarkup inlineKeyboardMarkup = new InlineKeyboardMarkup();
      List<List<InlineKeyboardButton>> keyboard = new ArrayList<>();

      for (User user : allByIsAdmin) {
         InlineKeyboardButton button = new InlineKeyboardButton();
         button.setText(user.getChatId()+"↔️"+user.getFirstname()+" "+user.getLastname());
         button.setCallbackData(String.valueOf(user.getChatId()));

         List<InlineKeyboardButton> row = new ArrayList<>();
         row.add(button);
         keyboard.add(row);
      }

      inlineKeyboardMarkup.setKeyboard(keyboard);

      return inlineKeyboardMarkup;
   }

}
