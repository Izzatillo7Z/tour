package uz.pdp.writepicture;


import lombok.RequiredArgsConstructor;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardRemove;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import uz.pdp.writepicture.entity.User;
import uz.pdp.writepicture.enums.UserState;
import uz.pdp.writepicture.respository.UserRepository;
import uz.pdp.writepicture.service.ButtonService;
import uz.pdp.writepicture.service.UserService;
import uz.pdp.writepicture.utils.MessageConstants;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import java.util.regex.Pattern;


@Component
@RequiredArgsConstructor
public class BotSender extends TelegramLongPollingBot {

    @Value("${telegram.bot.token}")
    private String botToken;

    @Value("${telegram.bot.username}")
    private String botUsername;

    private final ButtonService buttonService;

    private final UserRepository userRepository;

    private final UserService userService;

    @Override
    public void onUpdateReceived(Update update) {




        if (update.hasMessage() && update.getMessage().hasText()) {
            Long chatId = update.getMessage().getChatId();
            String text = update.getMessage().getText();

            Optional<User> optionalUser = userRepository.findByChatId(chatId);

            if (optionalUser.isPresent()) {
                if (optionalUser.get().isSuperAdmin()) {

                    if(text.equals("/start")){
                        ReplyKeyboardMarkup superAdminButton = buttonService.getSuperAdminButton();

                        String messageText="Bizning xizmatimizdan foydalanishingiz mumkin!";
                        sendButtonAndText(chatId,messageText,superAdminButton);
                    }

                    else if(update.getMessage().getText().equals(MessageConstants.ADD_ADMIN)){

                        sendText(chatId,"Admin qo'shmoqchimisiz? " +
                                "\n Adminning TELEGRAM CHAT ID sini kiriting🔽" +
                                "\n Masalan : id:15789782" );

                    }
                    else if(update.getMessage().getText().equals(MessageConstants.DELETE_ADMIN)){

                        InlineKeyboardMarkup adminDeleteButton = buttonService.getAdminDeleteButton();
                        sendInlineButtonAndText(chatId,
                                "Qaysi birini adminlikdan bo'shatmoqchisiz? \n Tanlang🔽",
                                adminDeleteButton);


                    }

                    else if(text.startsWith("id:")){
                        text= text.replace("id:","");
                        text= text.replace(" ","");

                        long chatIdAdmin = Long.parseLong(text);
                        User user = User.builder().isAdmin(true)
                                .chatId(chatIdAdmin).build();
                        userRepository.save(user);

                        sendText(chatId,"Admin muvaffaqiyatli qo'shildi!");

                    }
                }

                else if (optionalUser.get().isAdmin()) {

                        // TODO admin logic yoziladi

                        if(text.equals("/start")){

                            Optional<User> optionalAdmin = userRepository.findByChatId(chatId);
                            if (optionalAdmin.isPresent()) {
                                User user = optionalAdmin.get();

                                String firstName = update.getMessage().getChat().getFirstName();
                                String lastname = update.getMessage().getChat().getLastName();
                                String userName = update.getMessage().getChat().getUserName();

                                user.setFirstname(firstName);
                                user.setUsername(userName);
                                user.setLastname(lastname);
                                user.setUserState(UserState.ASK_FROM);
                                userRepository.save(user);

                                checkUserState(chatId);

                            }

                        }
                        else {

                            Optional<User> optionalAdmin = userRepository.findByChatId(chatId);

                            if (optionalAdmin.isPresent()) {

                                User user = optionalAdmin.get();

                                if(user.getUserState().equals(UserState.ASK_FROM)){
                                    user.setUserFrom(text.toUpperCase()+"-");
                                    user.setUserState(UserState.ASK_TO);
                                    userRepository.save(user);
                                }
                                else if (user.getUserState().equals(UserState.ASK_TO)) {
                                    user.setUserTo(text.toUpperCase());
                                    user.setUserState(UserState.ASK_DATE_FROM);
                                    userRepository.save(user);
                                }
                                else if (user.getUserState().equals(UserState.ASK_DATE_FROM)) {

                                    if (!Pattern.matches(MessageConstants.DATE_REGEX,text)){

                                        sendText(chatId,"kk/oo/yyyy  formatda kiriting.\n " +
                                                "Qaytadan urinib ko'ring🔁" );
                                        return;
                                    }
                                    user.setDateFrom(text);
                                    user.setUserState(UserState.ASK_DATE_TO);
                                    userRepository.save(user);
                                }
                                else if (user.getUserState().equals(UserState.ASK_DATE_TO)) {

                                    if (!Pattern.matches(MessageConstants.DATE_REGEX,text)){

                                        sendText(chatId,"kk/oo/yyyy  formatda kiriting.\n " +
                                                "Qaytadan urinib ko'ring🔁" );
                                        return;
                                    }
                                    user.setDateTo(text);
                                    user.setUserState(UserState.ASK_DURATION_DAY);
                                    userRepository.save(user);

                                }
                                else if (user.getUserState().equals(UserState.ASK_DURATION_DAY)) {

                                    if(!text.matches("\\d+")){
                                        sendText(chatId,"Faqat son kiriting.\n " +
                                                "Qaytadan urinib ko'ring🔁" );
                                        return;
                                    }

                                    user.setDurationDay(text);
                                    user.setUserState(UserState.ASK_DURATION_NIGHT);
                                    userRepository.save(user);
                                }

                                else if (user.getUserState().equals(UserState.ASK_DURATION_NIGHT)) {
                                    if(!text.matches("^\\d+$")){
                                        sendText(chatId,"Faqat son kiriting.\n " +
                                                "Qaytadan urinib ko'ring🔁" );
                                        return;
                                    }

                                    user.setDurationNight(text);
                                    user.setUserState(UserState.ASK_PRICE);
                                    userRepository.save(user);
                                } else if (user.getUserState().equals(UserState.ASK_PRICE)) {

                                    user.setPrice(text);
                                    user.setUserState(UserState.COMPLETED);
                                    userRepository.save(user);
                                }


                                checkUserState(chatId);

                            }

                        }


                }

            }

            else {
                String messageText="Sizda bu botdan foydalanishingiz uchun adminlik huquqi yo'q❌";
                sendText(chatId,messageText);
            }
        }
        else if(update.hasCallbackQuery()){

            Long adminChatId = Long.parseLong(update.getCallbackQuery().getData());

            Long chatId = update.getCallbackQuery().getMessage().getChatId();

            userService.deleteUser(adminChatId);
            sendText(chatId,"Admin muvoffaqiyatli o'chirildi!");
        }




    }

    private void checkUserState(Long chatId) {

        Optional<User> optionalUser = userRepository.findByChatId(chatId);

        if (optionalUser.isEmpty()) {
            sendText(chatId,"Sizda bu botdan foydalanishingiz uchun adminlik huquqi yo'q❌");
        }
        else {

            User user = optionalUser.get();

            UserState userState = user.getUserState();

            switch (userState){

                case ASK_FROM:sendText(chatId,"🛫 Qayerdan uchmoqchisiz?"); ;break;

                case ASK_TO:sendText(chatId,"\uD83D\uDCCD Qayerga uchmoqchisiz?");break;

                case ASK_DATE_FROM: sendText(chatId,"\uD83D\uDCC5 Jo'nab ketish sanasi" +
                        "\n(kun/oy/yil)\n formatda kiriting."); ;break;

                case ASK_DATE_TO:sendText(chatId,"\uD83D\uDCC6 Qaytish sanasi"+
                        "\n(kun/oy/yil)\n formatda kiriting.");break;

                case ASK_DURATION_DAY:sendText(chatId,"\uD83D\uDD52 Sayohat necha kunduz davom qiladi.\n Faqat son yozing.Masalan: 9");break;

                case ASK_DURATION_NIGHT:sendText(chatId,"\uD83D\uDD52 Sayohat necha kecha davom qiladi.");break;

                case ASK_PRICE:sendText(chatId,"💰 Narxi qancha? \nMasalan: 499$");break;

                case COMPLETED: completedState(chatId) ;break;

            }


        }

    }

    private void completedState(Long chatId) {

        sendText(chatId,"Hamma malumotlar olindi ozgina kutib turing." +
                "\nRasm tayyorlanmoqda...🔃");

        Optional<User> optionalUser = userRepository.findByChatId(chatId);
        if (optionalUser.isEmpty()) {
            sendText(chatId,"Sizda bu botdan foydalanishingiz uchun adminlik huquqi yo'q❌");
        }
        else{

           BufferedImage image= generatePicture(optionalUser.get());

             sendPictureBot(chatId,image);



            sendText(chatId,"Botimizdan yana foydlanmoqchimisiz?\n" +
                    "/start ni bosing va yana rasm chiqarib oling.");

        }
    }

    private void sendPictureBot(Long chatId, BufferedImage image) {

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {


            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(image, "png", baos);
            byte[] imageBytes = baos.toByteArray();

            String url = "https://api.telegram.org/bot" + botToken + "/sendPhoto";

            HttpPost post = new HttpPost(url);
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.addTextBody("chat_id", String.valueOf(chatId));
            builder.addBinaryBody("photo", new ByteArrayInputStream(imageBytes), org.apache.http.entity.ContentType.IMAGE_PNG, "image.png");

            HttpEntity entity = builder.build();
            post.setEntity(entity);


            HttpResponse response = httpClient.execute(post);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public BufferedImage generatePicture(User user) {
        try {
            BufferedImage image = ImageIO.read(new File("input.png"));
            Graphics2D g = image.createGraphics();
            g.setColor(Color.WHITE);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Montserrat shriftini yuklash
            Font baseFont = Font.createFont(Font.TRUETYPE_FONT, new File("src/main/resources/fonts/Montserrat-Bold.ttf"));

            // Matnlar uchun mos shrift topish va markazlash
            drawCenteredText(g, baseFont, user.getUserFrom(), 1080, 324, 110);
            drawCenteredText(g, baseFont, user.getUserTo(), 1080, 444, 110);

            drawCenteredText(g, baseFont, MessageConstants.JONASH_SANASI_MESSAGE, 1080, 644, 55);
            drawCenteredText(g, baseFont, user.getDateFrom(), 1080, 700, 55);

            drawCenteredText(g, baseFont, MessageConstants.QAYTISH_SANASI_MESSAGE, 1080, 900, 55);
            drawCenteredText(g, baseFont, user.getDateTo(), 1080, 960, 55);

            drawCenteredText(g, baseFont, MessageConstants.SAYOHAT_DAVRI_MESSAGE, 1080, 1160, 55);
            drawCenteredText(g, baseFont,  user.getDurationNight() + MessageConstants.KECHA_MESSAGE
                            +user.getDurationDay() + MessageConstants.KUNDUZ_MESSAGE
                    , 1080, 1210, 55);

            drawCenteredText(g, baseFont, user.getPrice(), 1080, 1410, 95);

            g.dispose();
            return image;

        } catch (IOException | FontFormatException e) {
            e.printStackTrace();
            return null;
        }
    }


    private void drawCenteredText(Graphics2D g, Font baseFont, String text, int maxWidth, int y, int maxSize) {
        FontRenderContext frc = g.getFontRenderContext();
        int fontSize = maxSize;

        while (fontSize > 10) {
            Font font = baseFont.deriveFont((float) fontSize);
            Rectangle2D textBounds = font.getStringBounds(text, frc);

            if (textBounds.getWidth() <= maxWidth - 40) {
                g.setFont(font);
                int x = (maxWidth - (int) textBounds.getWidth()) / 2;
                g.drawString(text, x, y);
                return;
            }
            fontSize--;
        }


        Font smallFont = baseFont.deriveFont(10f);
        g.setFont(smallFont);
        Rectangle2D textBounds = smallFont.getStringBounds(text, frc);
        int x = (maxWidth - (int) textBounds.getWidth()) / 2;
        g.drawString(text, x, y);
    }


    private void sendButtonAndText(Long chatId, String text,ReplyKeyboardMarkup replyKeyboardMarkup) {

        SendMessage sendMessage = new SendMessage();
        sendMessage.setText(text);
        sendMessage.setReplyMarkup(replyKeyboardMarkup);
        sendMessage.setChatId(chatId);

        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private void sendInlineButtonAndText(Long chatId, String text,InlineKeyboardMarkup inlineKeyboardMarkup) {

        SendMessage sendMessage = new SendMessage();
        sendMessage.setText(text);
        sendMessage.setReplyMarkup(inlineKeyboardMarkup);
        sendMessage.setChatId(chatId);

        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private void sendButton(Long chatId, ReplyKeyboardMarkup replyKeyboardMarkup) {

        SendMessage sendMessage = new SendMessage();
        sendMessage.setReplyMarkup(replyKeyboardMarkup);
        sendMessage.setChatId(chatId);

        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private void sendText(Long chatId, String text) {

        SendMessage sendMessage = new SendMessage();
        sendMessage.setText(text);
        sendMessage.setChatId(chatId);

        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }



    public void deleteContactButton(Long chatId) {

        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(chatId);
        sendMessage.setText("Telefon raqamingizni ulashganingiz uchun rahmat!");
        sendMessage.setReplyMarkup(new ReplyKeyboardRemove(true));

        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }

    }

    @Override
    public String getBotUsername() {
        return botUsername;
    }

    @Override
    public String getBotToken() {
        return botToken;
    }
}
