package uz.pdp.writepicture.respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import uz.pdp.writepicture.entity.User;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<User, UUID> {

    Optional<User> findByChatId(Long chatId);

    void deleteByChatId(Long chatId);


    @Query("SELECT u FROM User u WHERE u.isAdmin = true")
    List<User> findAllAdmins();

}
