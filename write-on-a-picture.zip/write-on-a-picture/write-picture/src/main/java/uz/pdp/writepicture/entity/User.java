package uz.pdp.writepicture.entity;


import jakarta.persistence.*;
import lombok.*;
import uz.pdp.writepicture.enums.UserState;

import java.util.UUID;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@Table(name = "users")
public class User {
    @Id
    @Column(nullable = false)
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false,name = "chat_id")
    private long chatId;

    private String username;

    private String firstname;

    private String lastname;

    private String userFrom;

    private String userTo;

    private String dateFrom;

    private String dateTo;

    private String durationDay;

    private String durationNight;

    private String price;

    @Enumerated(EnumType.STRING)
    private UserState userState;


    private boolean isSuperAdmin;

    private boolean isAdmin;
}
